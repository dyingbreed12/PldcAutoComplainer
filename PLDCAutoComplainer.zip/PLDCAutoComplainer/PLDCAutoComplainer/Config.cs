﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PLDCAutoComplainer
{
    public static class Config
    {
        public static string GetAppSettingsKey(string key = "")
        {
            string val = ConfigurationManager.AppSettings[key];

            return val;
        }
    }
}
