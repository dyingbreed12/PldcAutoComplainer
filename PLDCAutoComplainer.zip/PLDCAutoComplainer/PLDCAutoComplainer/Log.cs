﻿using NLog;
using System;

namespace PLDCAutoComplainer
{
    public static class Log
    {
        private static Logger _instance = null;

        static Log()
        {
            _instance = LogManager.GetCurrentClassLogger();
        }

        public static void LogInfo(string msg)
        {
            _instance.Info(msg);
        }

        public static void LogWarning(string msg)
        {
            _instance.Warn(msg);
        }

        public static void LogError(string msg)
        {
            _instance.Error(msg);
        }

        public static void LogException(Exception ex)
        {
            _instance.Error(ex.ToString());
        }
    }

}
