﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace PLDCAutoComplainer
{
    public class MailHelper
    {
        private const int Timeout = 180000;
        private readonly string _host;
        private readonly int _port;
        private readonly string _user;
        private readonly string _pass;
        private readonly bool _ssl;

        public string Sender { get; set; }
        public string Recipient { get; set; }
        public string RecipientCC { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
        public Attachment AttachmentFile { get; set; }
        public string ContentID { get; set; }

        public MailHelper()
        {
            //MailServer - Represents the SMTP Server
            _host = Config.GetAppSettingsKey("Host");
            //Port- Represents the port number
            _port = int.Parse(Config.GetAppSettingsKey("Port"));
            //MailAuthUser and MailAuthPass - Used for Authentication for sending email
            _user = Config.GetAppSettingsKey("EmailAddress");
            _pass = Config.GetAppSettingsKey("Password");
            _ssl = Convert.ToBoolean(Config.GetAppSettingsKey("Ssl"));
        }

        public void Send()
        {
            var smtp = new SmtpClient();
            var message = new MailMessage(Sender, Recipient, Subject, Body) { IsBodyHtml = true };

            if (AttachmentFile != null)
            {
                message.Attachments.Add(AttachmentFile);
                message.Body = message.Body.Replace("speedtestimage", "cid:" + ContentID);
            }

            try
            {
                if (RecipientCC != null)
                {
                    message.Bcc.Add(RecipientCC);
                }

                smtp = new SmtpClient(_host, _port);

                if (_user.Length > 0 && _pass.Length > 0)
                {
                    smtp.UseDefaultCredentials = false;
                    smtp.Credentials = new NetworkCredential(_user, _pass);
                    smtp.EnableSsl = _ssl;
                }

                smtp.Send(message);
            }

            catch (Exception ex)
            {
                Log.LogException(ex);
            }
            finally
            {
                message.Dispose();
                smtp.Dispose();
            }
        }
    }
}
