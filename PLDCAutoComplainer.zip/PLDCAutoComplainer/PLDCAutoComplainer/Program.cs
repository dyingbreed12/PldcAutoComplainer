﻿using System;
using System.IO;
using System.Net.Mail;
using System.Net.Mime;
using System.Reflection;

namespace PLDCAutoComplainer
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Stand By! Sending Your Complain....");
            bool result = SendDirectEmail();

            if (result)
                Console.WriteLine("Yeah! Your Complain Has Been Sent To PLDC! :)");
            else
            {
                Console.WriteLine("Oh No! Failed To Send Your Complain, Please Check App.Config if you miss something or try again later maybe your internet is Experiencing PLDC! Please try again ! ");
            }
            Console.ReadLine();
        }

        public static bool SendDirectEmail()
        {
            StreamReader textStreamReader = null;
            Assembly assem = Assembly.GetExecutingAssembly();

            try
            {
                Stream stream = typeof(StringResources).Assembly.GetManifestResourceStream("PLDCAutoComplainer.Template.PLDCEmailTemplate.txt");
                StreamReader reader = new StreamReader(stream);
                string body = reader.ReadToEnd();

                // add email logic here to email user
                string sender = Config.GetAppSettingsKey("EmailAddress");
                string emailSubject = Config.GetAppSettingsKey("EmailTitle");
                // add email for user
                string useremail = Config.GetAppSettingsKey("PldcEmail");
                var dateTimeNow = DateTime.Now.ToString("MMMM dd, yyyy");

                var speedTestImage = Config.GetAppSettingsKey("SpeedTestImage");
                var accountNumber = Config.GetAppSettingsKey("AccountNumber");
                var accountHolder = Config.GetAppSettingsKey("AccountHolder");
                var telNumber = Config.GetAppSettingsKey("TelNumber");
                var city = Config.GetAppSettingsKey("City");
                var country = Config.GetAppSettingsKey("Country");
                
                string messageBody = string.Format(body, dateTimeNow, accountNumber, accountHolder, telNumber, city, country);
                // Add the alternate views instead of using MailMessage.Body
                
                MailMessage emailMessage = new MailMessage();
                emailMessage.Body = messageBody;

                string image = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, $"{speedTestImage}");
                string contentID = Path.GetFileName(image).Replace(".", "") + "@zofm";

                // create the INLINE attachment
                Attachment inline = new Attachment(image);
                inline.ContentDisposition.Inline = true;
                inline.ContentDisposition.DispositionType = DispositionTypeNames.Inline;
                inline.ContentId = contentID;
                inline.ContentType.MediaType = "image/png";
                inline.ContentType.Name = Path.GetFileName(image);
                emailMessage.Attachments.Add(inline);
                emailMessage.IsBodyHtml = true;


                var MailHelper = new MailHelper
                {
                    Sender = sender, //email.Sender,
                    Recipient = useremail,
                    RecipientCC = null,
                    Subject = emailSubject,
                    Body = messageBody,
                    AttachmentFile = inline,
                    ContentID = contentID
                };

                MailHelper.Send();

                return true;
            }

            catch (Exception ex)
            {
                Log.LogException(ex);
            }
            finally
            {
                if (textStreamReader != null)
                    textStreamReader.Close();
            }
            return false;
        }
    }
}
